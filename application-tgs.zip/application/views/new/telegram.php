
<div align="" style="padding:400px 0 0 250px">
    <img src="<?php echo base_url();?>website_assets/sc logo.png" alt="logo" style="max-width:500px;">
    </div>
<script>
setTimeout(function() {
  window.location.href = "https://telegram.me/theglobalscholarship";
}, 100);
</script>