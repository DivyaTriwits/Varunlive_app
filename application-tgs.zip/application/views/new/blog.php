<!--====================================Ambassador Section====================================-->
<section id="services-section" class="services-section-area s-pd1" style="background: #ffff !important; padding-bottom:18px">
   <div class="container">
      <div class="row justify-content-md-center">
         <div class="col-lg-12">
            <h1 class="">Blog</h1>
            <br>
            <div class="row">
            <div class="col-lg-8">
            <p style="line-height:45px ">
               Blog
            </p>
            <p style="line-height:45px ">
                asdf
            </p>
            </div>
            <div class="col-lg-4">
           
                    <iframe  width="100%" height="300" src="https://www.youtube.com/embed/HAMmNg0LPCw" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                
            </div>
            </div>
             
            <div class="container">
               
               
            </div>
            <div class="responsibilities">
               <h1 class="">Mission</h1>
               <!--<h3 class="page-heading" style="color: #ff7f45;">Ambassador</h3>-->
               <p class="" style="line-height:40px ">
                 To support 1 million students benefit financially in their studies by getting scholarship.
               </p>
             
             
               
                      
                     <img src="<?php echo base_url()?>assets/images/about2.png" alt="Branding-Img" >
                   
            </div>
            <div class="responsibilities">
               <h1 class="">Vision</h1>
               
               <p class="" style="line-height:40px ">
                 To benefit maximum students to achieve almost free education. 
               </p>
               <br>
               <h1 class="">Our process: </h1>
               <ul align="" style="line-height:40px ">
                   <li>
                       1.	A team dedicatedly curates the available scholarship by crosschecking facts and verifying with the concerned authorities. 
                   </li>
                   <li>2.	Segregates every details required for students for filling up the application form. </li>
                   <li>3.	Post on our portal and benefit of students.</li>
                   <li>4.	Notify student via mail, message, and application notification</li>
                   <li>5.	We make sure that every details of scholarships will be posted on our  <a href="https://www.instagram.com/the_global_scholarship/" target=_bank><u style="color:blue">Instagram page</u></a>, Follow us for more updates</li>
               </ul>
               <br>
              
              
            </div>
            
         </div>
      </div>
   </div>
</section>
<section id="contact services-section " class="services-section-area s-pd1" style="background: #ffff !important; padding-top:10px !important">
   <div class="container" id="contact">
      <div class="row justify-content-md-center">
         <div class="col-lg-12">
           
            <div >
                <h1 class="">Why to Choose Us.?
 </h1>
               <ul align="" style="line-height:40px ">
                <li>  1.	Application start date notification.</li>
                 <li> 2.	Required document check list.</li>
                 <li> 3.	Proper channel for application.</li>
                 <li> 4.	Simplified application process.</li>
                 <li> 5.	Form filling support for students.</li>
                 <li> 6.	Application Process Video on YouTube, Subscribe to our <a href="https://www.youtube.com/c/theglobalscholarshiporg" target=_bank><u style="color:blue">YouTube</u></a> Channel.</li>
                 <li> 7.	Regular reminders.</li>
                 <li> 8.	SMS notification.</li>
                 <li> 9.	Custom E-mail notification.</li>
                 <li> 10.	Dedicate support for student. </li>
                 <li> 11.	Reminder notification before application end date.</li>

               </ul>
               
            </div>
            
          
            
         </div>
      </div>
   </div>
</section>